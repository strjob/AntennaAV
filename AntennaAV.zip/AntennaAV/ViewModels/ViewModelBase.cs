﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AntennaAV.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
